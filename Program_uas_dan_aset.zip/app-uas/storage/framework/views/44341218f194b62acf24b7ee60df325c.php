<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Details</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        img {
            max-width: 200px;
            height: auto;
            display: block;
            margin: 10px 0;
        }
    </style>
</head>
<body>

    <h1>EVENT DETAILS</h1>
    <a href="<?php echo e(route('dashboard.index')); ?>">Back to Dashboard List</a>
    <br />
    Event: <?php echo e($activity->event); ?> <br />
    Tanggal Event: <?php echo e($activity->tanggalevent); ?> <br />
    Deskripsi: <?php echo e($activity->deskripsi); ?> <br />
    Foto: <img src="<?php echo e(asset('storage/' . $activity->foto)); ?>" alt="Dashboard Image">

</body>
</html>

<?php /**PATH D:\xampp\htdocs\uaswebpro\app-uas\resources\views/dashboard/show.blade.php ENDPATH**/ ?>