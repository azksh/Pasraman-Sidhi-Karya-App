<img src="img/logo.png" class="h-10 inline " alt="">
<?php /**PATH D:\xampp\htdocs\uaswebpro\app-uas\resources\views/components/application-logo.blade.php ENDPATH**/ ?>