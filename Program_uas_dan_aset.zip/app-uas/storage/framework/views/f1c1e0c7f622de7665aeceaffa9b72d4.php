<?php echo csrf_field(); ?>
<?php /**PATH D:\xampp\htdocs\uaswebpro\app-uas\resources\views/pasraman/csrf.blade.php ENDPATH**/ ?>