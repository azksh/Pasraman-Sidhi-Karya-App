<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contact Mail</title>
</head>
<body>
    <p>Name: <?php echo e($data['name']); ?></p>
    <p>Email: <?php echo e($data['email']); ?></p>
    <p>Subject: <?php echo e($data['subject']); ?></p>
    <p>Message: <?php echo e($data['message']); ?></p>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\uaswebpro\app-uas\resources\views/mails/contact_mail.blade.php ENDPATH**/ ?>